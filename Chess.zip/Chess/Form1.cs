﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chess
{
    public partial class Form1 : Form
    {

        public List<string> Pieces = new List<string>() { "WhiteQRook", "WhiteQKnight", "WhiteQBishop", "WhiteQueen", "WhiteKing", "WhiteKBishop", "WhiteKKnight", "WhiteKRook", "WhiteApawn", "WhiteBpawn", "WhiteCpawn", "WhiteDpawn", "WhiteEpawn", "WhiteFpawn", "WhiteGpawn", "WhiteHpawn", "BlackQRook", "BlackQKnight", "BlackQBishop", "BlackQueen", "BlackKing", "BlackKBishop", "BlackKKnight", "BlackKRook", "BlackApawn", "BlackBpawn", "BlackCpawn", "BlackDpawn", "BlackEpawn", "BlackFpawn", "BlackGpawn", "BlackHpawn" };
        public List<string> Positions = new List<string>() { "11", "21", "31", "41", "51", "61", "71", "81", "12", "22", "32", "42", "52", "62", "72", "82", "18", "28", "38", "48", "58", "68", "78", "88", "17", "27", "37", "47", "57", "67", "77", "87" };
        public List<string> Highlighted = new List<string>();
        public int moveNumber = 1;
        public int IndexOfSquare;
        public string SelectedPiece;
        public string SelectedPieceSquare;
        public int SelectedPieceLocationX;
        public int SelectedPieceLocationY;

        
        public Form1()
        {
            InitializeComponent();


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void WhiteQRook_Click(object sender, EventArgs e)
        {
            //Get name of selected piece 
            Recolor();
            PictureBox name = (PictureBox)sender;
            SelectedPiece = name.Name;
            //Get X,Y location of selected piece
            SelectedPieceLocationX = name.Location.X;
            SelectedPieceLocationY = name.Location.Y;
            Highlight();
            RemoveIllegal();
            for (int i = 0; i < Highlighted.Count; i++)
            {
                this.Controls[Highlighted[i]].BackColor = Color.Green;
            }
            Highlighted.Clear();
        }

        private void A11_Click(object sender, EventArgs e)
        {

            Point NewPoint = new Point();
            //Chess board tile clicked
            PictureBox square = (PictureBox)sender;
            string SquareName = square.Name;
            if (this.Controls[SquareName].BackColor == Color.Green)
            {
                NewPoint.X = SelectedPieceLocationX + (Convert.ToInt32(SquareName.Substring(1, 1)) - Convert.ToInt32(SelectedPieceSquare.Substring(0, 1))) * 70;
                NewPoint.Y = SelectedPieceLocationY + (Convert.ToInt32(SelectedPieceSquare.Substring(1, 1)) - Convert.ToInt32(SquareName.Substring(2, 1))) * 70;
                this.Controls[SelectedPiece].Location = NewPoint;
                Recolor();
                this.Controls[SelectedPiece].BackColor = this.Controls[SquareName].BackColor;
                Positions[IndexOfSquare] = SquareName.Substring(1, 2);
                moveNumber++;

            }


        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            {
                Pen Border = new Pen(Color.Brown, 10);

                e.Graphics.DrawRectangle(Border, 7, 7, 565, 565);
            }
        }

        void Highlight()
        {
            int X, Y;
            IndexOfSquare = Pieces.IndexOf(SelectedPiece);
            SelectedPieceSquare = Positions[IndexOfSquare];
            X = Convert.ToInt32(SelectedPieceSquare.Substring(0, 1));
            Y = Convert.ToInt32(SelectedPieceSquare.Substring(1, 1));
            //pawn movement
            if (SelectedPiece.Contains("pawn"))
            {
                if (SelectedPiece.Contains("White"))
                {
                    Highlighted.Add($"_{X}{Y + 1}");
                    Highlighted.Add($"_{X}{Y + 2}");

                }
                else
                {
                    Highlighted.Add($"_{X}{Y - 1}");
                    Highlighted.Add($"_{X}{Y - 2}");

                }

            }
            //Rook movement
            else if (SelectedPiece.Contains("Rook"))
            {
                for (int i = X + 1; i < 9; i++)
                {
                    Highlighted.Add($"_{i}{Y}");
                }
                for (int i = X - 1; 0 < i; i--)
                {
                    Highlighted.Add($"_{i}{Y}");
                }
                for (int i = Y + 1; i < 9; i++)
                {
                    Highlighted.Add($"_{X}{i}");
                }
                for (int i = Y - 1; 0 < i; i--)
                {
                    Highlighted.Add($"_{X}{i}");
                }
            }
            //Bishop movement
            else if (SelectedPiece.Contains("Bishop"))
            {
                for (int x = X + 1, y = Y + 1; x < 9 && y < 9; x++, y++)
                {
                    Highlighted.Add($"_{x}{y}");
                }
                for (int x = X - 1, y = Y + 1; 0 < x && y < 9; x--, y++)
                {
                    Highlighted.Add($"_{x}{y}");
                }
                for (int x = X + 1, y = Y - 1; x < 9 && 0 < y; x++, y--)
                {
                    Highlighted.Add($"_{x}{y}");
                }
                for (int x = X - 1, y = Y - 1; 0 < x && 0 < y; x--, y--)
                {
                    Highlighted.Add($"_{x}{y}");
                }
            }
            //Queen movement
            else if (SelectedPiece.Contains("Queen"))
            {
                for (int i = X + 1; i < 9; i++)
                {
                    Highlighted.Add($"_{i}{Y}");
                }
                for (int i = X - 1; 0 < i; i--)
                {
                    Highlighted.Add($"_{i}{Y}");
                }
                for (int i = Y + 1; i < 9; i++)
                {
                    Highlighted.Add($"_{X}{i}");
                }
                for (int i = Y - 1; 0 < i; i--)
                {
                    Highlighted.Add($"_{X}{i}");
                }

                for (int x = X + 1, y = Y + 1; x < 9 && y < 9; x++, y++)
                {
                    Highlighted.Add($"_{x}{y}");
                }
                for (int x = X - 1, y = Y + 1; 0 < x && y < 9; x--, y++)
                {
                    Highlighted.Add($"_{x}{y}");
                }
                for (int x = X + 1, y = Y - 1; x < 9 && 0 < y; x++, y--)
                {
                    Highlighted.Add($"_{x}{y}");
                }
                for (int x = X - 1, y = Y - 1; 0 < x && 0 < y; x--, y--)
                {
                    Highlighted.Add($"_{x}{y}");
                }

            }
            //Knight movement
            else if (SelectedPiece.Contains("Knight"))
            {
                if (X + 2 < 9 && Y + 1 < 9)
                {
                    Highlighted.Add($"_{X + 2}{Y + 1}");
                }
                if (X + 1 < 9 && Y + 2 < 9)
                {
                    Highlighted.Add($"_{X + 1}{Y + 2}");
                }
                if (X - 1 > 0 && Y + 2 < 9)
                {
                    Highlighted.Add($"_{X - 1}{Y + 2}");
                }
                if (X - 2 > 0 && Y + 1 < 9)
                {
                    Highlighted.Add($"_{X - 2}{Y + 1}");
                }
                if (X - 2 > 0 && Y - 1 > 0)
                {
                    Highlighted.Add($"_{X - 2}{Y - 1}");
                }
                if (X - 1 > 0 && Y - 2 > 0)
                {
                    Highlighted.Add($"_{X - 1}{Y - 2}");
                }
                if (X + 2 < 9 && Y - 1 > 0)
                {
                    Highlighted.Add($"_{X + 2}{Y - 1}");
                }
                if (X + 1 < 9 && Y - 2 > 0)
                {
                    Highlighted.Add($"_{X + 1}{Y - 2}");
                }

            }
            //King movement
            else if (SelectedPiece.Contains("King"))
            {
                if (X + 1 < 9)
                {
                    Highlighted.Add($"_{X + 1}{Y}");
                    if (Y + 1 < 9)
                    {
                        Highlighted.Add($"_{X + 1}{Y + 1}");
                    }
                    if (Y - 1 > 0)
                    {
                        Highlighted.Add($"_{X + 1}{Y - 1}");
                    }

                }
                if (X - 1 > 0)
                {
                    Highlighted.Add($"_{X - 1}{Y}");
                    if (Y + 1 < 9)
                    {
                        Highlighted.Add($"_{X - 1}{Y + 1}");
                    }
                    if (Y - 1 > 0)
                    {
                        Highlighted.Add($"_{X - 1}{Y - 1}");
                    }

                }
                if (Y + 1 < 9)
                {
                    Highlighted.Add($"_{X}{Y + 1}");
                }
                if (Y - 1 > 0)
                {
                    Highlighted.Add($"_{X}{Y - 1}");
                }
            }
        }
        void RemoveIllegal()
        {
            int startingPositionX = Convert.ToInt32(SelectedPieceSquare.Substring(0,1));
            int startingPositionY = Convert.ToInt32(SelectedPieceSquare.Substring(1, 1));
            List<string> listHigh = new List<string>();
            var high = from h in Highlighted
                       select h.Substring(1, 2);
            foreach(string pos in high)
            {
                listHigh.Add(pos);
            }
            var colision = listHigh.Intersect(Positions);
            bool deciderX,deciderY;
            int cpX, cpY;
            if(colision!=null)
            {
                //colision for pawns
                if (SelectedPiece.Contains("pawn"))
                {
                    foreach(string pos in colision)
                    {
                        Highlighted.Remove($"_{pos}");
                    }
                }
                //colision for rooks
                if(SelectedPiece.Contains("Rook"))
                {
                    foreach (string colisionPoint in colision)
                    {
                        cpX = Convert.ToInt32(colisionPoint.Substring(0, 1));
                        cpY = Convert.ToInt32(colisionPoint.Substring(1, 1));
                        deciderX = startingPositionX!= cpX;
                        deciderY = startingPositionY!= cpY;
                        if (deciderX==true)
                        {
                            deciderX= startingPositionX>cpX;
                            if (deciderX == true)
                            {
                                for(int x=cpX ;x>0;x--)
                                {
                                    Highlighted.Remove($"_{x}{cpY}");
                                }
                            }
                            if (deciderX == false)
                            {
                                for (int x = cpX; x < 9; x++)
                                {
                                    Highlighted.Remove($"_{x}{cpY}");
                                }
                            }
                        }
                        if (deciderY == true)
                        {
                            deciderY = startingPositionY > cpY;
                            if (deciderY == true)
                            {
                                for (int y = cpY; y > 0; y--)
                                {
                                    Highlighted.Remove($"_{cpX}{y}");
                                }
                            }
                            if (deciderY == false)
                            {
                                for (int y = cpY; y < 9; y++)
                                {
                                    Highlighted.Remove($"_{cpX}{y}");
                                }
                            }
                        }

                    }
                }
                //colision for bishops
                if (SelectedPiece.Contains("Bishop"))
                {
                    foreach(string colisionPoint in colision)
                    {
                        cpX = Convert.ToInt32(colisionPoint.Substring(0, 1));
                        cpY = Convert.ToInt32(colisionPoint.Substring(1, 1));
                        deciderX = startingPositionX > cpX;
                        deciderY = startingPositionY > cpY;
                        if(deciderX==true&&deciderY==true)
                        {
                            for (int x = cpX, y = cpY; x > 0 && y > 0; x--,y--)
                            {
                                Highlighted.Remove($"_{x}{y}");
                            }
                        }
                        else if (deciderX == true && deciderY == false)
                        {
                            for (int x = cpX, y = cpY; x > 0 && y < 9; x--, y++)
                            {
                                Highlighted.Remove($"_{x}{y}");
                            }
                        }
                        else if (deciderX == false && deciderY == true)
                        {
                            for (int x = cpX, y = cpY; x < 9 && y > 0; x++, y--)
                            {
                                Highlighted.Remove($"_{x}{y}");
                            }
                        }
                        else if (deciderX == false && deciderY == false)
                        {
                            for (int x = cpX, y = cpY; x <9 && y <9; x++, y++)
                            {
                                Highlighted.Remove($"_{x}{y}");
                            }
                        }
                    }
                }
                //colision for queens
                if (SelectedPiece.Contains("Queen"))
                {

                }
                //colision for knights
                if (SelectedPiece.Contains("Knight"))
                {
                    foreach (string pos in colision)
                    {
                        Highlighted.Remove($"_{pos}");
                    }
                }
                //colision for kings
                if (SelectedPiece.Contains("King"))
                {
                    foreach (string pos in colision)
                    {
                        Highlighted.Remove($"_{pos}");
                    }
                }
            }
        }
        void Recolor()
        {
            //Recolor of the board
            for (int x = 1; x < 9; x+=2)
            {
                for(int y = 1; y < 9;y+=2)
                {
                    this.Controls[$"_{x}{y}"].BackColor=Color.LightBlue;
                }
            }
            for (int x = 2; x < 9; x += 2)
            {
                for (int y = 2; y < 9; y += 2)
                {
                    this.Controls[$"_{x}{y}"].BackColor = Color.LightBlue;
                }
            }
            for (int x = 1; x < 9; x += 2)
            {
                for (int y = 2; y < 9; y += 2)
                {
                    this.Controls[$"_{x}{y}"].BackColor = Color.White;
                }
            }
            for (int x = 2; x < 9; x += 2)
            {
                for (int y = 1; y < 9; y += 2)
                {
                    this.Controls[$"_{x}{y}"].BackColor = Color.White;
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            var blackPieces = from b in Pieces
                              where b.Contains("Black")
                              select b;
            var whitePieces = from w in Pieces
                              where w.Contains("White")
                              select w;
            if (moveNumber % 2 == 1)
            {

                foreach (string wpiece in whitePieces)
                {
                    this.Controls[wpiece].Enabled = true;
                }
                foreach (string bpiece in blackPieces)
                {
                    this.Controls[bpiece].Enabled=false;
                }

            }
            else
            {
                foreach (string wpiece in whitePieces)
                {
                    this.Controls[wpiece].Enabled = false;
                }
                foreach (string bpiece in blackPieces)
                {
                    this.Controls[bpiece].Enabled = true;
                }
            }
            
        }
    }

}
