﻿namespace Chess
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.WhiteQRook = new System.Windows.Forms.PictureBox();
            this.WhiteQKnight = new System.Windows.Forms.PictureBox();
            this.WhiteQBishop = new System.Windows.Forms.PictureBox();
            this.WhiteQueen = new System.Windows.Forms.PictureBox();
            this.WhiteKing = new System.Windows.Forms.PictureBox();
            this.WhiteKBishop = new System.Windows.Forms.PictureBox();
            this.WhiteKKnight = new System.Windows.Forms.PictureBox();
            this.WhiteKRook = new System.Windows.Forms.PictureBox();
            this.WhiteApawn = new System.Windows.Forms.PictureBox();
            this.WhiteBpawn = new System.Windows.Forms.PictureBox();
            this.WhiteCpawn = new System.Windows.Forms.PictureBox();
            this.WhiteDpawn = new System.Windows.Forms.PictureBox();
            this.WhiteEpawn = new System.Windows.Forms.PictureBox();
            this.WhiteFpawn = new System.Windows.Forms.PictureBox();
            this.WhiteGpawn = new System.Windows.Forms.PictureBox();
            this.WhiteHpawn = new System.Windows.Forms.PictureBox();
            this.BlackApawn = new System.Windows.Forms.PictureBox();
            this.BlackBpawn = new System.Windows.Forms.PictureBox();
            this.BlackCpawn = new System.Windows.Forms.PictureBox();
            this.BlackDpawn = new System.Windows.Forms.PictureBox();
            this.BlackEpawn = new System.Windows.Forms.PictureBox();
            this.BlackFpawn = new System.Windows.Forms.PictureBox();
            this.BlackGpawn = new System.Windows.Forms.PictureBox();
            this.BlackHpawn = new System.Windows.Forms.PictureBox();
            this.BlackQRook = new System.Windows.Forms.PictureBox();
            this.BlackQKnight = new System.Windows.Forms.PictureBox();
            this.BlackQBishop = new System.Windows.Forms.PictureBox();
            this.BlackQueen = new System.Windows.Forms.PictureBox();
            this.BlackKing = new System.Windows.Forms.PictureBox();
            this.BlackKBishop = new System.Windows.Forms.PictureBox();
            this.BlackKKnight = new System.Windows.Forms.PictureBox();
            this.BlackKRook = new System.Windows.Forms.PictureBox();
            this._81 = new System.Windows.Forms.PictureBox();
            this._71 = new System.Windows.Forms.PictureBox();
            this._61 = new System.Windows.Forms.PictureBox();
            this._51 = new System.Windows.Forms.PictureBox();
            this._41 = new System.Windows.Forms.PictureBox();
            this._31 = new System.Windows.Forms.PictureBox();
            this._21 = new System.Windows.Forms.PictureBox();
            this._11 = new System.Windows.Forms.PictureBox();
            this._82 = new System.Windows.Forms.PictureBox();
            this._72 = new System.Windows.Forms.PictureBox();
            this._62 = new System.Windows.Forms.PictureBox();
            this._52 = new System.Windows.Forms.PictureBox();
            this._42 = new System.Windows.Forms.PictureBox();
            this._32 = new System.Windows.Forms.PictureBox();
            this._22 = new System.Windows.Forms.PictureBox();
            this._12 = new System.Windows.Forms.PictureBox();
            this._83 = new System.Windows.Forms.PictureBox();
            this._73 = new System.Windows.Forms.PictureBox();
            this._63 = new System.Windows.Forms.PictureBox();
            this._53 = new System.Windows.Forms.PictureBox();
            this._43 = new System.Windows.Forms.PictureBox();
            this._33 = new System.Windows.Forms.PictureBox();
            this._23 = new System.Windows.Forms.PictureBox();
            this._13 = new System.Windows.Forms.PictureBox();
            this._84 = new System.Windows.Forms.PictureBox();
            this._74 = new System.Windows.Forms.PictureBox();
            this._64 = new System.Windows.Forms.PictureBox();
            this._54 = new System.Windows.Forms.PictureBox();
            this._44 = new System.Windows.Forms.PictureBox();
            this._34 = new System.Windows.Forms.PictureBox();
            this._24 = new System.Windows.Forms.PictureBox();
            this._14 = new System.Windows.Forms.PictureBox();
            this._85 = new System.Windows.Forms.PictureBox();
            this._75 = new System.Windows.Forms.PictureBox();
            this._65 = new System.Windows.Forms.PictureBox();
            this._55 = new System.Windows.Forms.PictureBox();
            this._45 = new System.Windows.Forms.PictureBox();
            this._35 = new System.Windows.Forms.PictureBox();
            this._25 = new System.Windows.Forms.PictureBox();
            this._15 = new System.Windows.Forms.PictureBox();
            this._86 = new System.Windows.Forms.PictureBox();
            this._76 = new System.Windows.Forms.PictureBox();
            this._66 = new System.Windows.Forms.PictureBox();
            this._56 = new System.Windows.Forms.PictureBox();
            this._46 = new System.Windows.Forms.PictureBox();
            this._36 = new System.Windows.Forms.PictureBox();
            this._26 = new System.Windows.Forms.PictureBox();
            this._16 = new System.Windows.Forms.PictureBox();
            this._87 = new System.Windows.Forms.PictureBox();
            this._77 = new System.Windows.Forms.PictureBox();
            this._67 = new System.Windows.Forms.PictureBox();
            this._57 = new System.Windows.Forms.PictureBox();
            this._47 = new System.Windows.Forms.PictureBox();
            this._37 = new System.Windows.Forms.PictureBox();
            this._27 = new System.Windows.Forms.PictureBox();
            this._17 = new System.Windows.Forms.PictureBox();
            this._88 = new System.Windows.Forms.PictureBox();
            this._78 = new System.Windows.Forms.PictureBox();
            this._68 = new System.Windows.Forms.PictureBox();
            this._58 = new System.Windows.Forms.PictureBox();
            this._48 = new System.Windows.Forms.PictureBox();
            this._38 = new System.Windows.Forms.PictureBox();
            this._28 = new System.Windows.Forms.PictureBox();
            this._18 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.WhiteQRook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteQKnight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteQBishop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteQueen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteKing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteKBishop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteKKnight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteKRook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteApawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteBpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteCpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteDpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteEpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteFpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteGpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteHpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackApawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackBpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackCpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackDpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackEpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackFpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackGpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackHpawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackQRook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackQKnight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackQBishop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackQueen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackKing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackKBishop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackKKnight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackKRook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // WhiteQRook
            // 
            this.WhiteQRook.BackColor = System.Drawing.Color.LightBlue;
            this.WhiteQRook.Image = ((System.Drawing.Image)(resources.GetObject("WhiteQRook.Image")));
            this.WhiteQRook.Location = new System.Drawing.Point(73, 533);
            this.WhiteQRook.Name = "WhiteQRook";
            this.WhiteQRook.Size = new System.Drawing.Size(50, 50);
            this.WhiteQRook.TabIndex = 193;
            this.WhiteQRook.TabStop = false;
            this.WhiteQRook.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteQKnight
            // 
            this.WhiteQKnight.BackColor = System.Drawing.Color.White;
            this.WhiteQKnight.Image = ((System.Drawing.Image)(resources.GetObject("WhiteQKnight.Image")));
            this.WhiteQKnight.Location = new System.Drawing.Point(143, 533);
            this.WhiteQKnight.Name = "WhiteQKnight";
            this.WhiteQKnight.Size = new System.Drawing.Size(50, 50);
            this.WhiteQKnight.TabIndex = 192;
            this.WhiteQKnight.TabStop = false;
            this.WhiteQKnight.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteQBishop
            // 
            this.WhiteQBishop.BackColor = System.Drawing.Color.LightBlue;
            this.WhiteQBishop.Image = ((System.Drawing.Image)(resources.GetObject("WhiteQBishop.Image")));
            this.WhiteQBishop.Location = new System.Drawing.Point(213, 533);
            this.WhiteQBishop.Name = "WhiteQBishop";
            this.WhiteQBishop.Size = new System.Drawing.Size(50, 50);
            this.WhiteQBishop.TabIndex = 191;
            this.WhiteQBishop.TabStop = false;
            this.WhiteQBishop.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteQueen
            // 
            this.WhiteQueen.BackColor = System.Drawing.Color.White;
            this.WhiteQueen.Image = global::Chess.Properties.Resources.WhiteQueen;
            this.WhiteQueen.Location = new System.Drawing.Point(283, 533);
            this.WhiteQueen.Name = "WhiteQueen";
            this.WhiteQueen.Size = new System.Drawing.Size(50, 50);
            this.WhiteQueen.TabIndex = 190;
            this.WhiteQueen.TabStop = false;
            this.WhiteQueen.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteKing
            // 
            this.WhiteKing.BackColor = System.Drawing.Color.LightBlue;
            this.WhiteKing.Image = global::Chess.Properties.Resources.WhiteKing;
            this.WhiteKing.Location = new System.Drawing.Point(353, 533);
            this.WhiteKing.Name = "WhiteKing";
            this.WhiteKing.Size = new System.Drawing.Size(50, 50);
            this.WhiteKing.TabIndex = 189;
            this.WhiteKing.TabStop = false;
            this.WhiteKing.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteKBishop
            // 
            this.WhiteKBishop.BackColor = System.Drawing.Color.White;
            this.WhiteKBishop.Image = ((System.Drawing.Image)(resources.GetObject("WhiteKBishop.Image")));
            this.WhiteKBishop.Location = new System.Drawing.Point(423, 533);
            this.WhiteKBishop.Name = "WhiteKBishop";
            this.WhiteKBishop.Size = new System.Drawing.Size(50, 50);
            this.WhiteKBishop.TabIndex = 188;
            this.WhiteKBishop.TabStop = false;
            this.WhiteKBishop.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteKKnight
            // 
            this.WhiteKKnight.BackColor = System.Drawing.Color.LightBlue;
            this.WhiteKKnight.Image = ((System.Drawing.Image)(resources.GetObject("WhiteKKnight.Image")));
            this.WhiteKKnight.Location = new System.Drawing.Point(493, 533);
            this.WhiteKKnight.Name = "WhiteKKnight";
            this.WhiteKKnight.Size = new System.Drawing.Size(50, 50);
            this.WhiteKKnight.TabIndex = 187;
            this.WhiteKKnight.TabStop = false;
            this.WhiteKKnight.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteKRook
            // 
            this.WhiteKRook.BackColor = System.Drawing.Color.White;
            this.WhiteKRook.Image = ((System.Drawing.Image)(resources.GetObject("WhiteKRook.Image")));
            this.WhiteKRook.Location = new System.Drawing.Point(563, 533);
            this.WhiteKRook.Name = "WhiteKRook";
            this.WhiteKRook.Size = new System.Drawing.Size(50, 50);
            this.WhiteKRook.TabIndex = 186;
            this.WhiteKRook.TabStop = false;
            this.WhiteKRook.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteApawn
            // 
            this.WhiteApawn.BackColor = System.Drawing.Color.White;
            this.WhiteApawn.Image = ((System.Drawing.Image)(resources.GetObject("WhiteApawn.Image")));
            this.WhiteApawn.Location = new System.Drawing.Point(73, 463);
            this.WhiteApawn.Name = "WhiteApawn";
            this.WhiteApawn.Size = new System.Drawing.Size(50, 50);
            this.WhiteApawn.TabIndex = 185;
            this.WhiteApawn.TabStop = false;
            this.WhiteApawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteBpawn
            // 
            this.WhiteBpawn.BackColor = System.Drawing.Color.LightBlue;
            this.WhiteBpawn.Image = ((System.Drawing.Image)(resources.GetObject("WhiteBpawn.Image")));
            this.WhiteBpawn.Location = new System.Drawing.Point(143, 463);
            this.WhiteBpawn.Name = "WhiteBpawn";
            this.WhiteBpawn.Size = new System.Drawing.Size(50, 50);
            this.WhiteBpawn.TabIndex = 184;
            this.WhiteBpawn.TabStop = false;
            this.WhiteBpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteCpawn
            // 
            this.WhiteCpawn.BackColor = System.Drawing.Color.White;
            this.WhiteCpawn.Image = ((System.Drawing.Image)(resources.GetObject("WhiteCpawn.Image")));
            this.WhiteCpawn.Location = new System.Drawing.Point(213, 463);
            this.WhiteCpawn.Name = "WhiteCpawn";
            this.WhiteCpawn.Size = new System.Drawing.Size(50, 50);
            this.WhiteCpawn.TabIndex = 183;
            this.WhiteCpawn.TabStop = false;
            this.WhiteCpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteDpawn
            // 
            this.WhiteDpawn.BackColor = System.Drawing.Color.LightBlue;
            this.WhiteDpawn.Image = ((System.Drawing.Image)(resources.GetObject("WhiteDpawn.Image")));
            this.WhiteDpawn.Location = new System.Drawing.Point(283, 463);
            this.WhiteDpawn.Name = "WhiteDpawn";
            this.WhiteDpawn.Size = new System.Drawing.Size(50, 50);
            this.WhiteDpawn.TabIndex = 182;
            this.WhiteDpawn.TabStop = false;
            this.WhiteDpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteEpawn
            // 
            this.WhiteEpawn.BackColor = System.Drawing.Color.White;
            this.WhiteEpawn.Image = ((System.Drawing.Image)(resources.GetObject("WhiteEpawn.Image")));
            this.WhiteEpawn.Location = new System.Drawing.Point(353, 463);
            this.WhiteEpawn.Name = "WhiteEpawn";
            this.WhiteEpawn.Size = new System.Drawing.Size(50, 50);
            this.WhiteEpawn.TabIndex = 181;
            this.WhiteEpawn.TabStop = false;
            this.WhiteEpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteFpawn
            // 
            this.WhiteFpawn.BackColor = System.Drawing.Color.LightBlue;
            this.WhiteFpawn.Image = ((System.Drawing.Image)(resources.GetObject("WhiteFpawn.Image")));
            this.WhiteFpawn.Location = new System.Drawing.Point(423, 463);
            this.WhiteFpawn.Name = "WhiteFpawn";
            this.WhiteFpawn.Size = new System.Drawing.Size(50, 50);
            this.WhiteFpawn.TabIndex = 180;
            this.WhiteFpawn.TabStop = false;
            this.WhiteFpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteGpawn
            // 
            this.WhiteGpawn.BackColor = System.Drawing.Color.White;
            this.WhiteGpawn.Image = ((System.Drawing.Image)(resources.GetObject("WhiteGpawn.Image")));
            this.WhiteGpawn.Location = new System.Drawing.Point(493, 463);
            this.WhiteGpawn.Name = "WhiteGpawn";
            this.WhiteGpawn.Size = new System.Drawing.Size(50, 50);
            this.WhiteGpawn.TabIndex = 179;
            this.WhiteGpawn.TabStop = false;
            this.WhiteGpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // WhiteHpawn
            // 
            this.WhiteHpawn.BackColor = System.Drawing.Color.LightBlue;
            this.WhiteHpawn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.WhiteHpawn.ErrorImage = null;
            this.WhiteHpawn.Image = ((System.Drawing.Image)(resources.GetObject("WhiteHpawn.Image")));
            this.WhiteHpawn.InitialImage = null;
            this.WhiteHpawn.Location = new System.Drawing.Point(563, 463);
            this.WhiteHpawn.Name = "WhiteHpawn";
            this.WhiteHpawn.Size = new System.Drawing.Size(50, 50);
            this.WhiteHpawn.TabIndex = 178;
            this.WhiteHpawn.TabStop = false;
            this.WhiteHpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackApawn
            // 
            this.BlackApawn.BackColor = System.Drawing.Color.LightBlue;
            this.BlackApawn.Image = ((System.Drawing.Image)(resources.GetObject("BlackApawn.Image")));
            this.BlackApawn.Location = new System.Drawing.Point(73, 113);
            this.BlackApawn.Name = "BlackApawn";
            this.BlackApawn.Size = new System.Drawing.Size(50, 50);
            this.BlackApawn.TabIndex = 177;
            this.BlackApawn.TabStop = false;
            this.BlackApawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackBpawn
            // 
            this.BlackBpawn.BackColor = System.Drawing.Color.White;
            this.BlackBpawn.Image = ((System.Drawing.Image)(resources.GetObject("BlackBpawn.Image")));
            this.BlackBpawn.Location = new System.Drawing.Point(143, 113);
            this.BlackBpawn.Name = "BlackBpawn";
            this.BlackBpawn.Size = new System.Drawing.Size(50, 50);
            this.BlackBpawn.TabIndex = 176;
            this.BlackBpawn.TabStop = false;
            this.BlackBpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackCpawn
            // 
            this.BlackCpawn.BackColor = System.Drawing.Color.LightBlue;
            this.BlackCpawn.Image = ((System.Drawing.Image)(resources.GetObject("BlackCpawn.Image")));
            this.BlackCpawn.Location = new System.Drawing.Point(213, 113);
            this.BlackCpawn.Name = "BlackCpawn";
            this.BlackCpawn.Size = new System.Drawing.Size(50, 50);
            this.BlackCpawn.TabIndex = 175;
            this.BlackCpawn.TabStop = false;
            this.BlackCpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackDpawn
            // 
            this.BlackDpawn.BackColor = System.Drawing.Color.White;
            this.BlackDpawn.Image = ((System.Drawing.Image)(resources.GetObject("BlackDpawn.Image")));
            this.BlackDpawn.Location = new System.Drawing.Point(283, 113);
            this.BlackDpawn.Name = "BlackDpawn";
            this.BlackDpawn.Size = new System.Drawing.Size(50, 50);
            this.BlackDpawn.TabIndex = 174;
            this.BlackDpawn.TabStop = false;
            this.BlackDpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackEpawn
            // 
            this.BlackEpawn.BackColor = System.Drawing.Color.LightBlue;
            this.BlackEpawn.Image = ((System.Drawing.Image)(resources.GetObject("BlackEpawn.Image")));
            this.BlackEpawn.Location = new System.Drawing.Point(353, 113);
            this.BlackEpawn.Name = "BlackEpawn";
            this.BlackEpawn.Size = new System.Drawing.Size(50, 50);
            this.BlackEpawn.TabIndex = 173;
            this.BlackEpawn.TabStop = false;
            this.BlackEpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackFpawn
            // 
            this.BlackFpawn.BackColor = System.Drawing.Color.White;
            this.BlackFpawn.Image = ((System.Drawing.Image)(resources.GetObject("BlackFpawn.Image")));
            this.BlackFpawn.Location = new System.Drawing.Point(423, 113);
            this.BlackFpawn.Name = "BlackFpawn";
            this.BlackFpawn.Size = new System.Drawing.Size(50, 50);
            this.BlackFpawn.TabIndex = 172;
            this.BlackFpawn.TabStop = false;
            this.BlackFpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackGpawn
            // 
            this.BlackGpawn.BackColor = System.Drawing.Color.LightBlue;
            this.BlackGpawn.Image = ((System.Drawing.Image)(resources.GetObject("BlackGpawn.Image")));
            this.BlackGpawn.Location = new System.Drawing.Point(493, 113);
            this.BlackGpawn.Name = "BlackGpawn";
            this.BlackGpawn.Size = new System.Drawing.Size(50, 50);
            this.BlackGpawn.TabIndex = 171;
            this.BlackGpawn.TabStop = false;
            this.BlackGpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackHpawn
            // 
            this.BlackHpawn.BackColor = System.Drawing.Color.White;
            this.BlackHpawn.Image = ((System.Drawing.Image)(resources.GetObject("BlackHpawn.Image")));
            this.BlackHpawn.Location = new System.Drawing.Point(563, 113);
            this.BlackHpawn.Name = "BlackHpawn";
            this.BlackHpawn.Size = new System.Drawing.Size(50, 50);
            this.BlackHpawn.TabIndex = 170;
            this.BlackHpawn.TabStop = false;
            this.BlackHpawn.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackQRook
            // 
            this.BlackQRook.BackColor = System.Drawing.Color.White;
            this.BlackQRook.Image = global::Chess.Properties.Resources.BlackRook;
            this.BlackQRook.Location = new System.Drawing.Point(73, 43);
            this.BlackQRook.Name = "BlackQRook";
            this.BlackQRook.Size = new System.Drawing.Size(50, 50);
            this.BlackQRook.TabIndex = 169;
            this.BlackQRook.TabStop = false;
            this.BlackQRook.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackQKnight
            // 
            this.BlackQKnight.BackColor = System.Drawing.Color.LightBlue;
            this.BlackQKnight.Image = global::Chess.Properties.Resources.BlackKnight;
            this.BlackQKnight.Location = new System.Drawing.Point(143, 43);
            this.BlackQKnight.Name = "BlackQKnight";
            this.BlackQKnight.Size = new System.Drawing.Size(50, 50);
            this.BlackQKnight.TabIndex = 168;
            this.BlackQKnight.TabStop = false;
            this.BlackQKnight.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackQBishop
            // 
            this.BlackQBishop.BackColor = System.Drawing.Color.White;
            this.BlackQBishop.Image = ((System.Drawing.Image)(resources.GetObject("BlackQBishop.Image")));
            this.BlackQBishop.Location = new System.Drawing.Point(213, 43);
            this.BlackQBishop.Name = "BlackQBishop";
            this.BlackQBishop.Size = new System.Drawing.Size(50, 50);
            this.BlackQBishop.TabIndex = 167;
            this.BlackQBishop.TabStop = false;
            this.BlackQBishop.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackQueen
            // 
            this.BlackQueen.BackColor = System.Drawing.Color.LightBlue;
            this.BlackQueen.Image = global::Chess.Properties.Resources.BlackQueen;
            this.BlackQueen.Location = new System.Drawing.Point(283, 43);
            this.BlackQueen.Name = "BlackQueen";
            this.BlackQueen.Size = new System.Drawing.Size(50, 50);
            this.BlackQueen.TabIndex = 166;
            this.BlackQueen.TabStop = false;
            this.BlackQueen.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackKing
            // 
            this.BlackKing.BackColor = System.Drawing.Color.White;
            this.BlackKing.Image = global::Chess.Properties.Resources.BlackKing;
            this.BlackKing.Location = new System.Drawing.Point(353, 43);
            this.BlackKing.Name = "BlackKing";
            this.BlackKing.Size = new System.Drawing.Size(50, 50);
            this.BlackKing.TabIndex = 165;
            this.BlackKing.TabStop = false;
            this.BlackKing.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackKBishop
            // 
            this.BlackKBishop.BackColor = System.Drawing.Color.LightBlue;
            this.BlackKBishop.Image = ((System.Drawing.Image)(resources.GetObject("BlackKBishop.Image")));
            this.BlackKBishop.Location = new System.Drawing.Point(423, 43);
            this.BlackKBishop.Name = "BlackKBishop";
            this.BlackKBishop.Size = new System.Drawing.Size(50, 50);
            this.BlackKBishop.TabIndex = 164;
            this.BlackKBishop.TabStop = false;
            this.BlackKBishop.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackKKnight
            // 
            this.BlackKKnight.BackColor = System.Drawing.Color.White;
            this.BlackKKnight.Image = global::Chess.Properties.Resources.BlackKnight;
            this.BlackKKnight.Location = new System.Drawing.Point(493, 43);
            this.BlackKKnight.Name = "BlackKKnight";
            this.BlackKKnight.Size = new System.Drawing.Size(50, 50);
            this.BlackKKnight.TabIndex = 163;
            this.BlackKKnight.TabStop = false;
            this.BlackKKnight.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // BlackKRook
            // 
            this.BlackKRook.BackColor = System.Drawing.Color.LightBlue;
            this.BlackKRook.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BlackKRook.BackgroundImage")));
            this.BlackKRook.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BlackKRook.ErrorImage = null;
            this.BlackKRook.Image = global::Chess.Properties.Resources.BlackRook;
            this.BlackKRook.InitialImage = null;
            this.BlackKRook.Location = new System.Drawing.Point(563, 43);
            this.BlackKRook.Name = "BlackKRook";
            this.BlackKRook.Size = new System.Drawing.Size(50, 50);
            this.BlackKRook.TabIndex = 162;
            this.BlackKRook.TabStop = false;
            this.BlackKRook.Click += new System.EventHandler(this.WhiteQRook_Click);
            // 
            // _81
            // 
            this._81.BackColor = System.Drawing.Color.White;
            this._81.Location = new System.Drawing.Point(553, 523);
            this._81.Name = "_81";
            this._81.Size = new System.Drawing.Size(70, 70);
            this._81.TabIndex = 160;
            this._81.TabStop = false;
            this._81.Click += new System.EventHandler(this.A11_Click);
            // 
            // _71
            // 
            this._71.BackColor = System.Drawing.Color.LightBlue;
            this._71.Location = new System.Drawing.Point(483, 523);
            this._71.Name = "_71";
            this._71.Size = new System.Drawing.Size(70, 70);
            this._71.TabIndex = 159;
            this._71.TabStop = false;
            this._71.Click += new System.EventHandler(this.A11_Click);
            // 
            // _61
            // 
            this._61.BackColor = System.Drawing.Color.White;
            this._61.Location = new System.Drawing.Point(413, 523);
            this._61.Name = "_61";
            this._61.Size = new System.Drawing.Size(70, 70);
            this._61.TabIndex = 158;
            this._61.TabStop = false;
            this._61.Click += new System.EventHandler(this.A11_Click);
            // 
            // _51
            // 
            this._51.BackColor = System.Drawing.Color.LightBlue;
            this._51.Location = new System.Drawing.Point(343, 523);
            this._51.Name = "_51";
            this._51.Size = new System.Drawing.Size(70, 70);
            this._51.TabIndex = 157;
            this._51.TabStop = false;
            this._51.Click += new System.EventHandler(this.A11_Click);
            // 
            // _41
            // 
            this._41.BackColor = System.Drawing.Color.White;
            this._41.Location = new System.Drawing.Point(273, 523);
            this._41.Name = "_41";
            this._41.Size = new System.Drawing.Size(70, 70);
            this._41.TabIndex = 156;
            this._41.TabStop = false;
            this._41.Click += new System.EventHandler(this.A11_Click);
            // 
            // _31
            // 
            this._31.BackColor = System.Drawing.Color.LightBlue;
            this._31.Location = new System.Drawing.Point(203, 523);
            this._31.Name = "_31";
            this._31.Size = new System.Drawing.Size(70, 70);
            this._31.TabIndex = 155;
            this._31.TabStop = false;
            this._31.Click += new System.EventHandler(this.A11_Click);
            // 
            // _21
            // 
            this._21.BackColor = System.Drawing.Color.White;
            this._21.Location = new System.Drawing.Point(133, 523);
            this._21.Name = "_21";
            this._21.Size = new System.Drawing.Size(70, 70);
            this._21.TabIndex = 154;
            this._21.TabStop = false;
            this._21.Click += new System.EventHandler(this.A11_Click);
            // 
            // _11
            // 
            this._11.BackColor = System.Drawing.Color.LightBlue;
            this._11.Location = new System.Drawing.Point(63, 523);
            this._11.Name = "_11";
            this._11.Size = new System.Drawing.Size(70, 70);
            this._11.TabIndex = 153;
            this._11.TabStop = false;
            this._11.Click += new System.EventHandler(this.A11_Click);
            // 
            // _82
            // 
            this._82.BackColor = System.Drawing.Color.LightBlue;
            this._82.Location = new System.Drawing.Point(553, 453);
            this._82.Name = "_82";
            this._82.Size = new System.Drawing.Size(70, 70);
            this._82.TabIndex = 152;
            this._82.TabStop = false;
            this._82.Click += new System.EventHandler(this.A11_Click);
            // 
            // _72
            // 
            this._72.BackColor = System.Drawing.Color.White;
            this._72.Location = new System.Drawing.Point(483, 453);
            this._72.Name = "_72";
            this._72.Size = new System.Drawing.Size(70, 70);
            this._72.TabIndex = 151;
            this._72.TabStop = false;
            this._72.Click += new System.EventHandler(this.A11_Click);
            // 
            // _62
            // 
            this._62.BackColor = System.Drawing.Color.LightBlue;
            this._62.Location = new System.Drawing.Point(413, 453);
            this._62.Name = "_62";
            this._62.Size = new System.Drawing.Size(70, 70);
            this._62.TabIndex = 150;
            this._62.TabStop = false;
            this._62.Click += new System.EventHandler(this.A11_Click);
            // 
            // _52
            // 
            this._52.BackColor = System.Drawing.Color.White;
            this._52.Location = new System.Drawing.Point(343, 453);
            this._52.Name = "_52";
            this._52.Size = new System.Drawing.Size(70, 70);
            this._52.TabIndex = 149;
            this._52.TabStop = false;
            this._52.Click += new System.EventHandler(this.A11_Click);
            // 
            // _42
            // 
            this._42.BackColor = System.Drawing.Color.LightBlue;
            this._42.Location = new System.Drawing.Point(273, 453);
            this._42.Name = "_42";
            this._42.Size = new System.Drawing.Size(70, 70);
            this._42.TabIndex = 148;
            this._42.TabStop = false;
            this._42.Click += new System.EventHandler(this.A11_Click);
            // 
            // _32
            // 
            this._32.BackColor = System.Drawing.Color.White;
            this._32.Location = new System.Drawing.Point(203, 453);
            this._32.Name = "_32";
            this._32.Size = new System.Drawing.Size(70, 70);
            this._32.TabIndex = 147;
            this._32.TabStop = false;
            this._32.Click += new System.EventHandler(this.A11_Click);
            // 
            // _22
            // 
            this._22.BackColor = System.Drawing.Color.LightBlue;
            this._22.Location = new System.Drawing.Point(133, 453);
            this._22.Name = "_22";
            this._22.Size = new System.Drawing.Size(70, 70);
            this._22.TabIndex = 146;
            this._22.TabStop = false;
            this._22.Click += new System.EventHandler(this.A11_Click);
            // 
            // _12
            // 
            this._12.BackColor = System.Drawing.Color.White;
            this._12.Location = new System.Drawing.Point(63, 453);
            this._12.Name = "_12";
            this._12.Size = new System.Drawing.Size(70, 70);
            this._12.TabIndex = 145;
            this._12.TabStop = false;
            this._12.Click += new System.EventHandler(this.A11_Click);
            // 
            // _83
            // 
            this._83.BackColor = System.Drawing.Color.White;
            this._83.Location = new System.Drawing.Point(553, 383);
            this._83.Name = "_83";
            this._83.Size = new System.Drawing.Size(70, 70);
            this._83.TabIndex = 144;
            this._83.TabStop = false;
            this._83.Click += new System.EventHandler(this.A11_Click);
            // 
            // _73
            // 
            this._73.BackColor = System.Drawing.Color.LightBlue;
            this._73.Location = new System.Drawing.Point(483, 383);
            this._73.Name = "_73";
            this._73.Size = new System.Drawing.Size(70, 70);
            this._73.TabIndex = 143;
            this._73.TabStop = false;
            this._73.Click += new System.EventHandler(this.A11_Click);
            // 
            // _63
            // 
            this._63.BackColor = System.Drawing.Color.White;
            this._63.Location = new System.Drawing.Point(413, 383);
            this._63.Name = "_63";
            this._63.Size = new System.Drawing.Size(70, 70);
            this._63.TabIndex = 142;
            this._63.TabStop = false;
            this._63.Click += new System.EventHandler(this.A11_Click);
            // 
            // _53
            // 
            this._53.BackColor = System.Drawing.Color.LightBlue;
            this._53.Location = new System.Drawing.Point(343, 383);
            this._53.Name = "_53";
            this._53.Size = new System.Drawing.Size(70, 70);
            this._53.TabIndex = 141;
            this._53.TabStop = false;
            this._53.Click += new System.EventHandler(this.A11_Click);
            // 
            // _43
            // 
            this._43.BackColor = System.Drawing.Color.White;
            this._43.Location = new System.Drawing.Point(273, 383);
            this._43.Name = "_43";
            this._43.Size = new System.Drawing.Size(70, 70);
            this._43.TabIndex = 140;
            this._43.TabStop = false;
            this._43.Click += new System.EventHandler(this.A11_Click);
            // 
            // _33
            // 
            this._33.BackColor = System.Drawing.Color.LightBlue;
            this._33.Location = new System.Drawing.Point(203, 383);
            this._33.Name = "_33";
            this._33.Size = new System.Drawing.Size(70, 70);
            this._33.TabIndex = 139;
            this._33.TabStop = false;
            this._33.Click += new System.EventHandler(this.A11_Click);
            // 
            // _23
            // 
            this._23.BackColor = System.Drawing.Color.White;
            this._23.Location = new System.Drawing.Point(133, 383);
            this._23.Name = "_23";
            this._23.Size = new System.Drawing.Size(70, 70);
            this._23.TabIndex = 138;
            this._23.TabStop = false;
            this._23.Click += new System.EventHandler(this.A11_Click);
            // 
            // _13
            // 
            this._13.BackColor = System.Drawing.Color.LightBlue;
            this._13.Location = new System.Drawing.Point(63, 383);
            this._13.Name = "_13";
            this._13.Size = new System.Drawing.Size(70, 70);
            this._13.TabIndex = 137;
            this._13.TabStop = false;
            this._13.Click += new System.EventHandler(this.A11_Click);
            // 
            // _84
            // 
            this._84.BackColor = System.Drawing.Color.LightBlue;
            this._84.Location = new System.Drawing.Point(553, 313);
            this._84.Name = "_84";
            this._84.Size = new System.Drawing.Size(70, 70);
            this._84.TabIndex = 136;
            this._84.TabStop = false;
            this._84.Click += new System.EventHandler(this.A11_Click);
            // 
            // _74
            // 
            this._74.BackColor = System.Drawing.Color.White;
            this._74.Location = new System.Drawing.Point(483, 313);
            this._74.Name = "_74";
            this._74.Size = new System.Drawing.Size(70, 70);
            this._74.TabIndex = 135;
            this._74.TabStop = false;
            this._74.Click += new System.EventHandler(this.A11_Click);
            // 
            // _64
            // 
            this._64.BackColor = System.Drawing.Color.LightBlue;
            this._64.Location = new System.Drawing.Point(413, 313);
            this._64.Name = "_64";
            this._64.Size = new System.Drawing.Size(70, 70);
            this._64.TabIndex = 134;
            this._64.TabStop = false;
            this._64.Click += new System.EventHandler(this.A11_Click);
            // 
            // _54
            // 
            this._54.BackColor = System.Drawing.Color.White;
            this._54.Location = new System.Drawing.Point(343, 313);
            this._54.Name = "_54";
            this._54.Size = new System.Drawing.Size(70, 70);
            this._54.TabIndex = 133;
            this._54.TabStop = false;
            this._54.Click += new System.EventHandler(this.A11_Click);
            // 
            // _44
            // 
            this._44.BackColor = System.Drawing.Color.LightBlue;
            this._44.Location = new System.Drawing.Point(273, 313);
            this._44.Name = "_44";
            this._44.Size = new System.Drawing.Size(70, 70);
            this._44.TabIndex = 132;
            this._44.TabStop = false;
            this._44.Click += new System.EventHandler(this.A11_Click);
            // 
            // _34
            // 
            this._34.BackColor = System.Drawing.Color.White;
            this._34.Location = new System.Drawing.Point(203, 313);
            this._34.Name = "_34";
            this._34.Size = new System.Drawing.Size(70, 70);
            this._34.TabIndex = 131;
            this._34.TabStop = false;
            this._34.Click += new System.EventHandler(this.A11_Click);
            // 
            // _24
            // 
            this._24.BackColor = System.Drawing.Color.LightBlue;
            this._24.Location = new System.Drawing.Point(133, 313);
            this._24.Name = "_24";
            this._24.Size = new System.Drawing.Size(70, 70);
            this._24.TabIndex = 130;
            this._24.TabStop = false;
            this._24.Click += new System.EventHandler(this.A11_Click);
            // 
            // _14
            // 
            this._14.BackColor = System.Drawing.Color.White;
            this._14.Location = new System.Drawing.Point(63, 313);
            this._14.Name = "_14";
            this._14.Size = new System.Drawing.Size(70, 70);
            this._14.TabIndex = 129;
            this._14.TabStop = false;
            this._14.Click += new System.EventHandler(this.A11_Click);
            // 
            // _85
            // 
            this._85.BackColor = System.Drawing.Color.White;
            this._85.Location = new System.Drawing.Point(553, 243);
            this._85.Name = "_85";
            this._85.Size = new System.Drawing.Size(70, 70);
            this._85.TabIndex = 128;
            this._85.TabStop = false;
            this._85.Click += new System.EventHandler(this.A11_Click);
            // 
            // _75
            // 
            this._75.BackColor = System.Drawing.Color.LightBlue;
            this._75.Location = new System.Drawing.Point(483, 243);
            this._75.Name = "_75";
            this._75.Size = new System.Drawing.Size(70, 70);
            this._75.TabIndex = 127;
            this._75.TabStop = false;
            this._75.Click += new System.EventHandler(this.A11_Click);
            // 
            // _65
            // 
            this._65.BackColor = System.Drawing.Color.White;
            this._65.Location = new System.Drawing.Point(413, 243);
            this._65.Name = "_65";
            this._65.Size = new System.Drawing.Size(70, 70);
            this._65.TabIndex = 126;
            this._65.TabStop = false;
            this._65.Click += new System.EventHandler(this.A11_Click);
            // 
            // _55
            // 
            this._55.BackColor = System.Drawing.Color.LightBlue;
            this._55.Location = new System.Drawing.Point(343, 243);
            this._55.Name = "_55";
            this._55.Size = new System.Drawing.Size(70, 70);
            this._55.TabIndex = 125;
            this._55.TabStop = false;
            this._55.Click += new System.EventHandler(this.A11_Click);
            // 
            // _45
            // 
            this._45.BackColor = System.Drawing.Color.White;
            this._45.Location = new System.Drawing.Point(273, 243);
            this._45.Name = "_45";
            this._45.Size = new System.Drawing.Size(70, 70);
            this._45.TabIndex = 124;
            this._45.TabStop = false;
            this._45.Click += new System.EventHandler(this.A11_Click);
            // 
            // _35
            // 
            this._35.BackColor = System.Drawing.Color.LightBlue;
            this._35.Location = new System.Drawing.Point(203, 243);
            this._35.Name = "_35";
            this._35.Size = new System.Drawing.Size(70, 70);
            this._35.TabIndex = 123;
            this._35.TabStop = false;
            this._35.Click += new System.EventHandler(this.A11_Click);
            // 
            // _25
            // 
            this._25.BackColor = System.Drawing.Color.White;
            this._25.Location = new System.Drawing.Point(133, 243);
            this._25.Name = "_25";
            this._25.Size = new System.Drawing.Size(70, 70);
            this._25.TabIndex = 122;
            this._25.TabStop = false;
            this._25.Click += new System.EventHandler(this.A11_Click);
            // 
            // _15
            // 
            this._15.BackColor = System.Drawing.Color.LightBlue;
            this._15.Location = new System.Drawing.Point(63, 243);
            this._15.Name = "_15";
            this._15.Size = new System.Drawing.Size(70, 70);
            this._15.TabIndex = 121;
            this._15.TabStop = false;
            this._15.Click += new System.EventHandler(this.A11_Click);
            // 
            // _86
            // 
            this._86.BackColor = System.Drawing.Color.LightBlue;
            this._86.Location = new System.Drawing.Point(553, 173);
            this._86.Name = "_86";
            this._86.Size = new System.Drawing.Size(70, 70);
            this._86.TabIndex = 120;
            this._86.TabStop = false;
            this._86.Click += new System.EventHandler(this.A11_Click);
            // 
            // _76
            // 
            this._76.BackColor = System.Drawing.Color.White;
            this._76.Location = new System.Drawing.Point(483, 173);
            this._76.Name = "_76";
            this._76.Size = new System.Drawing.Size(70, 70);
            this._76.TabIndex = 119;
            this._76.TabStop = false;
            this._76.Click += new System.EventHandler(this.A11_Click);
            // 
            // _66
            // 
            this._66.BackColor = System.Drawing.Color.LightBlue;
            this._66.Location = new System.Drawing.Point(413, 173);
            this._66.Name = "_66";
            this._66.Size = new System.Drawing.Size(70, 70);
            this._66.TabIndex = 118;
            this._66.TabStop = false;
            this._66.Click += new System.EventHandler(this.A11_Click);
            // 
            // _56
            // 
            this._56.BackColor = System.Drawing.Color.White;
            this._56.Location = new System.Drawing.Point(343, 173);
            this._56.Name = "_56";
            this._56.Size = new System.Drawing.Size(70, 70);
            this._56.TabIndex = 117;
            this._56.TabStop = false;
            this._56.Click += new System.EventHandler(this.A11_Click);
            // 
            // _46
            // 
            this._46.BackColor = System.Drawing.Color.LightBlue;
            this._46.Location = new System.Drawing.Point(273, 173);
            this._46.Name = "_46";
            this._46.Size = new System.Drawing.Size(70, 70);
            this._46.TabIndex = 116;
            this._46.TabStop = false;
            this._46.Click += new System.EventHandler(this.A11_Click);
            // 
            // _36
            // 
            this._36.BackColor = System.Drawing.Color.White;
            this._36.Location = new System.Drawing.Point(203, 173);
            this._36.Name = "_36";
            this._36.Size = new System.Drawing.Size(70, 70);
            this._36.TabIndex = 115;
            this._36.TabStop = false;
            this._36.Click += new System.EventHandler(this.A11_Click);
            // 
            // _26
            // 
            this._26.BackColor = System.Drawing.Color.LightBlue;
            this._26.Location = new System.Drawing.Point(133, 173);
            this._26.Name = "_26";
            this._26.Size = new System.Drawing.Size(70, 70);
            this._26.TabIndex = 114;
            this._26.TabStop = false;
            this._26.Click += new System.EventHandler(this.A11_Click);
            // 
            // _16
            // 
            this._16.BackColor = System.Drawing.Color.White;
            this._16.Location = new System.Drawing.Point(63, 173);
            this._16.Name = "_16";
            this._16.Size = new System.Drawing.Size(70, 70);
            this._16.TabIndex = 113;
            this._16.TabStop = false;
            this._16.Click += new System.EventHandler(this.A11_Click);
            // 
            // _87
            // 
            this._87.BackColor = System.Drawing.Color.White;
            this._87.Location = new System.Drawing.Point(553, 103);
            this._87.Name = "_87";
            this._87.Size = new System.Drawing.Size(70, 70);
            this._87.TabIndex = 112;
            this._87.TabStop = false;
            this._87.Click += new System.EventHandler(this.A11_Click);
            // 
            // _77
            // 
            this._77.BackColor = System.Drawing.Color.LightBlue;
            this._77.Location = new System.Drawing.Point(483, 103);
            this._77.Name = "_77";
            this._77.Size = new System.Drawing.Size(70, 70);
            this._77.TabIndex = 111;
            this._77.TabStop = false;
            this._77.Click += new System.EventHandler(this.A11_Click);
            // 
            // _67
            // 
            this._67.BackColor = System.Drawing.Color.White;
            this._67.Location = new System.Drawing.Point(413, 103);
            this._67.Name = "_67";
            this._67.Size = new System.Drawing.Size(70, 70);
            this._67.TabIndex = 110;
            this._67.TabStop = false;
            this._67.Click += new System.EventHandler(this.A11_Click);
            // 
            // _57
            // 
            this._57.BackColor = System.Drawing.Color.LightBlue;
            this._57.Location = new System.Drawing.Point(343, 103);
            this._57.Name = "_57";
            this._57.Size = new System.Drawing.Size(70, 70);
            this._57.TabIndex = 109;
            this._57.TabStop = false;
            this._57.Click += new System.EventHandler(this.A11_Click);
            // 
            // _47
            // 
            this._47.BackColor = System.Drawing.Color.White;
            this._47.Location = new System.Drawing.Point(273, 103);
            this._47.Name = "_47";
            this._47.Size = new System.Drawing.Size(70, 70);
            this._47.TabIndex = 108;
            this._47.TabStop = false;
            this._47.Click += new System.EventHandler(this.A11_Click);
            // 
            // _37
            // 
            this._37.BackColor = System.Drawing.Color.LightBlue;
            this._37.Location = new System.Drawing.Point(203, 103);
            this._37.Name = "_37";
            this._37.Size = new System.Drawing.Size(70, 70);
            this._37.TabIndex = 107;
            this._37.TabStop = false;
            this._37.Click += new System.EventHandler(this.A11_Click);
            // 
            // _27
            // 
            this._27.BackColor = System.Drawing.Color.White;
            this._27.Location = new System.Drawing.Point(133, 103);
            this._27.Name = "_27";
            this._27.Size = new System.Drawing.Size(70, 70);
            this._27.TabIndex = 106;
            this._27.TabStop = false;
            this._27.Click += new System.EventHandler(this.A11_Click);
            // 
            // _17
            // 
            this._17.BackColor = System.Drawing.Color.LightBlue;
            this._17.Location = new System.Drawing.Point(63, 103);
            this._17.Name = "_17";
            this._17.Size = new System.Drawing.Size(70, 70);
            this._17.TabIndex = 105;
            this._17.TabStop = false;
            this._17.Click += new System.EventHandler(this.A11_Click);
            // 
            // _88
            // 
            this._88.BackColor = System.Drawing.Color.LightBlue;
            this._88.Location = new System.Drawing.Point(553, 33);
            this._88.Name = "_88";
            this._88.Size = new System.Drawing.Size(70, 70);
            this._88.TabIndex = 104;
            this._88.TabStop = false;
            this._88.Click += new System.EventHandler(this.A11_Click);
            // 
            // _78
            // 
            this._78.BackColor = System.Drawing.Color.White;
            this._78.Location = new System.Drawing.Point(483, 33);
            this._78.Name = "_78";
            this._78.Size = new System.Drawing.Size(70, 70);
            this._78.TabIndex = 103;
            this._78.TabStop = false;
            this._78.Click += new System.EventHandler(this.A11_Click);
            // 
            // _68
            // 
            this._68.BackColor = System.Drawing.Color.LightBlue;
            this._68.Location = new System.Drawing.Point(413, 33);
            this._68.Name = "_68";
            this._68.Size = new System.Drawing.Size(70, 70);
            this._68.TabIndex = 102;
            this._68.TabStop = false;
            this._68.Click += new System.EventHandler(this.A11_Click);
            // 
            // _58
            // 
            this._58.BackColor = System.Drawing.Color.White;
            this._58.Location = new System.Drawing.Point(343, 33);
            this._58.Name = "_58";
            this._58.Size = new System.Drawing.Size(70, 70);
            this._58.TabIndex = 101;
            this._58.TabStop = false;
            this._58.Click += new System.EventHandler(this.A11_Click);
            // 
            // _48
            // 
            this._48.BackColor = System.Drawing.Color.LightBlue;
            this._48.Location = new System.Drawing.Point(273, 33);
            this._48.Name = "_48";
            this._48.Size = new System.Drawing.Size(70, 70);
            this._48.TabIndex = 100;
            this._48.TabStop = false;
            this._48.Click += new System.EventHandler(this.A11_Click);
            // 
            // _38
            // 
            this._38.BackColor = System.Drawing.Color.White;
            this._38.Location = new System.Drawing.Point(203, 33);
            this._38.Name = "_38";
            this._38.Size = new System.Drawing.Size(70, 70);
            this._38.TabIndex = 99;
            this._38.TabStop = false;
            this._38.Click += new System.EventHandler(this.A11_Click);
            // 
            // _28
            // 
            this._28.BackColor = System.Drawing.Color.LightBlue;
            this._28.Location = new System.Drawing.Point(133, 33);
            this._28.Name = "_28";
            this._28.Size = new System.Drawing.Size(70, 70);
            this._28.TabIndex = 98;
            this._28.TabStop = false;
            this._28.Click += new System.EventHandler(this.A11_Click);
            // 
            // _18
            // 
            this._18.BackColor = System.Drawing.Color.White;
            this._18.Location = new System.Drawing.Point(63, 33);
            this._18.Name = "_18";
            this._18.Size = new System.Drawing.Size(70, 70);
            this._18.TabIndex = 97;
            this._18.TabStop = false;
            this._18.Click += new System.EventHandler(this.A11_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(53, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(580, 580);
            this.pictureBox1.TabIndex = 161;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(927, 618);
            this.Controls.Add(this.WhiteQRook);
            this.Controls.Add(this.WhiteQKnight);
            this.Controls.Add(this.WhiteQBishop);
            this.Controls.Add(this.WhiteQueen);
            this.Controls.Add(this.WhiteKing);
            this.Controls.Add(this.WhiteKBishop);
            this.Controls.Add(this.WhiteKKnight);
            this.Controls.Add(this.WhiteKRook);
            this.Controls.Add(this.WhiteApawn);
            this.Controls.Add(this.WhiteBpawn);
            this.Controls.Add(this.WhiteCpawn);
            this.Controls.Add(this.WhiteDpawn);
            this.Controls.Add(this.WhiteEpawn);
            this.Controls.Add(this.WhiteFpawn);
            this.Controls.Add(this.WhiteGpawn);
            this.Controls.Add(this.WhiteHpawn);
            this.Controls.Add(this.BlackApawn);
            this.Controls.Add(this.BlackBpawn);
            this.Controls.Add(this.BlackCpawn);
            this.Controls.Add(this.BlackDpawn);
            this.Controls.Add(this.BlackEpawn);
            this.Controls.Add(this.BlackFpawn);
            this.Controls.Add(this.BlackGpawn);
            this.Controls.Add(this.BlackHpawn);
            this.Controls.Add(this.BlackQRook);
            this.Controls.Add(this.BlackQKnight);
            this.Controls.Add(this.BlackQBishop);
            this.Controls.Add(this.BlackQueen);
            this.Controls.Add(this.BlackKing);
            this.Controls.Add(this.BlackKBishop);
            this.Controls.Add(this.BlackKKnight);
            this.Controls.Add(this.BlackKRook);
            this.Controls.Add(this._81);
            this.Controls.Add(this._71);
            this.Controls.Add(this._61);
            this.Controls.Add(this._51);
            this.Controls.Add(this._41);
            this.Controls.Add(this._31);
            this.Controls.Add(this._21);
            this.Controls.Add(this._11);
            this.Controls.Add(this._82);
            this.Controls.Add(this._72);
            this.Controls.Add(this._62);
            this.Controls.Add(this._52);
            this.Controls.Add(this._42);
            this.Controls.Add(this._32);
            this.Controls.Add(this._22);
            this.Controls.Add(this._12);
            this.Controls.Add(this._83);
            this.Controls.Add(this._73);
            this.Controls.Add(this._63);
            this.Controls.Add(this._53);
            this.Controls.Add(this._43);
            this.Controls.Add(this._33);
            this.Controls.Add(this._23);
            this.Controls.Add(this._13);
            this.Controls.Add(this._84);
            this.Controls.Add(this._74);
            this.Controls.Add(this._64);
            this.Controls.Add(this._54);
            this.Controls.Add(this._44);
            this.Controls.Add(this._34);
            this.Controls.Add(this._24);
            this.Controls.Add(this._14);
            this.Controls.Add(this._85);
            this.Controls.Add(this._75);
            this.Controls.Add(this._65);
            this.Controls.Add(this._55);
            this.Controls.Add(this._45);
            this.Controls.Add(this._35);
            this.Controls.Add(this._25);
            this.Controls.Add(this._15);
            this.Controls.Add(this._86);
            this.Controls.Add(this._76);
            this.Controls.Add(this._66);
            this.Controls.Add(this._56);
            this.Controls.Add(this._46);
            this.Controls.Add(this._36);
            this.Controls.Add(this._26);
            this.Controls.Add(this._16);
            this.Controls.Add(this._87);
            this.Controls.Add(this._77);
            this.Controls.Add(this._67);
            this.Controls.Add(this._57);
            this.Controls.Add(this._47);
            this.Controls.Add(this._37);
            this.Controls.Add(this._27);
            this.Controls.Add(this._17);
            this.Controls.Add(this._88);
            this.Controls.Add(this._78);
            this.Controls.Add(this._68);
            this.Controls.Add(this._58);
            this.Controls.Add(this._48);
            this.Controls.Add(this._38);
            this.Controls.Add(this._28);
            this.Controls.Add(this._18);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.WhiteQRook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteQKnight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteQBishop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteQueen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteKing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteKBishop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteKKnight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteKRook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteApawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteBpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteCpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteDpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteEpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteFpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteGpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteHpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackApawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackBpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackCpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackDpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackEpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackFpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackGpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackHpawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackQRook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackQKnight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackQBishop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackQueen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackKing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackKBishop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackKKnight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackKRook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox WhiteQRook;
        private System.Windows.Forms.PictureBox WhiteQKnight;
        private System.Windows.Forms.PictureBox WhiteQBishop;
        private System.Windows.Forms.PictureBox WhiteQueen;
        private System.Windows.Forms.PictureBox WhiteKing;
        private System.Windows.Forms.PictureBox WhiteKBishop;
        private System.Windows.Forms.PictureBox WhiteKKnight;
        private System.Windows.Forms.PictureBox WhiteKRook;
        private System.Windows.Forms.PictureBox WhiteApawn;
        private System.Windows.Forms.PictureBox WhiteBpawn;
        private System.Windows.Forms.PictureBox WhiteCpawn;
        private System.Windows.Forms.PictureBox WhiteDpawn;
        private System.Windows.Forms.PictureBox WhiteEpawn;
        private System.Windows.Forms.PictureBox WhiteFpawn;
        private System.Windows.Forms.PictureBox WhiteGpawn;
        private System.Windows.Forms.PictureBox WhiteHpawn;
        private System.Windows.Forms.PictureBox BlackApawn;
        private System.Windows.Forms.PictureBox BlackBpawn;
        private System.Windows.Forms.PictureBox BlackCpawn;
        private System.Windows.Forms.PictureBox BlackDpawn;
        private System.Windows.Forms.PictureBox BlackEpawn;
        private System.Windows.Forms.PictureBox BlackFpawn;
        private System.Windows.Forms.PictureBox BlackGpawn;
        private System.Windows.Forms.PictureBox BlackHpawn;
        private System.Windows.Forms.PictureBox BlackQRook;
        private System.Windows.Forms.PictureBox BlackQKnight;
        private System.Windows.Forms.PictureBox BlackQBishop;
        private System.Windows.Forms.PictureBox BlackQueen;
        private System.Windows.Forms.PictureBox BlackKing;
        private System.Windows.Forms.PictureBox BlackKBishop;
        private System.Windows.Forms.PictureBox BlackKKnight;
        private System.Windows.Forms.PictureBox BlackKRook;
        private System.Windows.Forms.PictureBox _81;
        private System.Windows.Forms.PictureBox _71;
        private System.Windows.Forms.PictureBox _61;
        private System.Windows.Forms.PictureBox _51;
        private System.Windows.Forms.PictureBox _41;
        private System.Windows.Forms.PictureBox _31;
        private System.Windows.Forms.PictureBox _21;
        private System.Windows.Forms.PictureBox _11;
        private System.Windows.Forms.PictureBox _82;
        private System.Windows.Forms.PictureBox _72;
        private System.Windows.Forms.PictureBox _62;
        private System.Windows.Forms.PictureBox _52;
        private System.Windows.Forms.PictureBox _42;
        private System.Windows.Forms.PictureBox _32;
        private System.Windows.Forms.PictureBox _22;
        private System.Windows.Forms.PictureBox _12;
        private System.Windows.Forms.PictureBox _83;
        private System.Windows.Forms.PictureBox _73;
        private System.Windows.Forms.PictureBox _63;
        private System.Windows.Forms.PictureBox _53;
        private System.Windows.Forms.PictureBox _43;
        private System.Windows.Forms.PictureBox _33;
        private System.Windows.Forms.PictureBox _23;
        private System.Windows.Forms.PictureBox _13;
        private System.Windows.Forms.PictureBox _84;
        private System.Windows.Forms.PictureBox _74;
        private System.Windows.Forms.PictureBox _64;
        private System.Windows.Forms.PictureBox _54;
        private System.Windows.Forms.PictureBox _44;
        private System.Windows.Forms.PictureBox _34;
        private System.Windows.Forms.PictureBox _24;
        private System.Windows.Forms.PictureBox _14;
        private System.Windows.Forms.PictureBox _85;
        private System.Windows.Forms.PictureBox _75;
        private System.Windows.Forms.PictureBox _65;
        private System.Windows.Forms.PictureBox _55;
        private System.Windows.Forms.PictureBox _45;
        private System.Windows.Forms.PictureBox _35;
        private System.Windows.Forms.PictureBox _25;
        private System.Windows.Forms.PictureBox _15;
        private System.Windows.Forms.PictureBox _86;
        private System.Windows.Forms.PictureBox _76;
        private System.Windows.Forms.PictureBox _66;
        private System.Windows.Forms.PictureBox _56;
        private System.Windows.Forms.PictureBox _46;
        private System.Windows.Forms.PictureBox _36;
        private System.Windows.Forms.PictureBox _26;
        private System.Windows.Forms.PictureBox _16;
        private System.Windows.Forms.PictureBox _87;
        private System.Windows.Forms.PictureBox _77;
        private System.Windows.Forms.PictureBox _67;
        private System.Windows.Forms.PictureBox _57;
        private System.Windows.Forms.PictureBox _47;
        private System.Windows.Forms.PictureBox _37;
        private System.Windows.Forms.PictureBox _27;
        private System.Windows.Forms.PictureBox _17;
        private System.Windows.Forms.PictureBox _88;
        private System.Windows.Forms.PictureBox _78;
        private System.Windows.Forms.PictureBox _68;
        private System.Windows.Forms.PictureBox _58;
        private System.Windows.Forms.PictureBox _48;
        private System.Windows.Forms.PictureBox _38;
        private System.Windows.Forms.PictureBox _28;
        private System.Windows.Forms.PictureBox _18;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
    }
}

